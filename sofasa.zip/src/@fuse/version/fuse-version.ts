import { Version } from '@fuse/version/version';

export const FUSE_VERSION = new Version('14.1.1').full;
